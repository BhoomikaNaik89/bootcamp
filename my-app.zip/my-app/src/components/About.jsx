import React from 'react'
import i1 from './image.png';
import './About.css';
function About() {
  return (
    <>
      <img src={i1} alt=" " className="image" />
  
   <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates dolor dolore, atque itaque voluptatum explicabo assumenda placeat vel nihil facere ipsa. Accusantium sed iusto consequatur dolores maiores. Eveniet, nobis reprehenderit.
   
   Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates dolor dolore, atque itaque voluptatum explicabo assumenda placeat vel nihil facere ipsa. Accusantium sed iusto consequatur dolores maiores. Eveniet, nobis reprehenderit.
   
   Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates dolor dolore, atque itaque voluptatum explicabo assumenda placeat vel nihil facere ipsa. Accusantium sed iusto consequatur dolores maiores. Eveniet, nobis reprehenderit.</p>
   
   
    </>
  )
}

export default About;
