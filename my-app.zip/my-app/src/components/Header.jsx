import React from 'react'

function Header() {
  return (
    <div>
      <div style={{textAlign:"center"}}>
      <h1 style={{letterSpacing:"2px"}}>SOFTWARE DEVELOPMENT</h1>
    </div>
    </div>

  )
}

export default Header
