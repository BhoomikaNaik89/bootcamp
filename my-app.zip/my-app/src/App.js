
import React from 'react'
import About from './components/About'
import Header from './components/Header'
import Footer from './components/Footer'
import Navbar from './components/Navbar'
import{BrowserRouter,Routes,Route} from 'react-router-dom';
import './App.css';
function App() {
  return (
    <div>
      <Navbar />
      <About/>
      <Header/>
      <br />
      <About/>
      <BrowserRouter>
      <Routes>
        <Route path='/about' element={<About/>}/>
        </Routes>
        </BrowserRouter>
      <About/>
      <Footer/>
    </div>
  )
}

export default App

